#!/usr/bin/python
import memcache,subprocess
from flask import Flask, render_template

app = Flask(__name__)

def get_memcachedata():

    NODES = ('127.0.0.1:11211',)
    mc = memcache.Client(NODES)
    g, out = mc.get_stats()[0]
    percent_mem_used = ( int(out["bytes"]) * 100 ) / int(out["limit_maxbytes"])
    percent_mem_used = str(percent_mem_used) + "%"
    out["get_hits"] = int(out["get_hits"])
    out["get_misses"] = int(out["get_misses"])
    get_total = int(out["cmd_get"])
    if get_total > 0 :
      percent_get_missed = (out["get_misses"] * 100 ) / get_total 
      percent_get_missed = str(percent_get_missed) + "%"
      percent_get_hit_rate = (out["get_hits"] * 100 ) / get_total
      percent_get_hit_rate = str(percent_get_hit_rate) + "%"
    else :
      percent_get_missed = '"cmd_get" is zero as of now'
      percent_get_hit_rate = '"cmd_get" is zero as of now'
    return out,percent_mem_used,percent_get_missed,percent_get_hit_rate

def get_sysdata():

    cmd = ['uptime']
    p = subprocess.Popen(cmd, stdout = subprocess.PIPE, stderr=subprocess.PIPE)
    out,err = p.communicate()
    return out

@app.route('/')
def index():
    mem_output, percent_mem_used, percent_get_missed, percent_get_hit_rate = get_memcachedata()
    subprocess_output = get_sysdata()
    subprocess_output = subprocess_output.split(',')
    uptime = subprocess_output[0]
    uptime = ' '.join(uptime.split(' ')[2:])
    users = subprocess_output[1]
    load5 = subprocess_output[2].split(':')[1] 
    load10 = subprocess_output[3] 
    load15 = subprocess_output[4] 
    return render_template('subprocess.html', subprocess_output = subprocess_output, uptime = uptime, users = users, load5 = load5, load10 = load10, load15 = load15, mem_output = mem_output, percent_mem_used = percent_mem_used, percent_get_missed = percent_get_missed, percent_get_hit_rate = percent_get_hit_rate ) 

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=80)
